'''
tamildhool deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests
import HTMLParser
import xbmcgui

class tdhool(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://www.tamildhool.com/'
        self.icon = self.ipath + 'tdhool.png'
        self.list = {'01Sun TV': 'suntvMMMM5',
                     '02Vijay TV': 'vijaytvMMMM5',
                     '03Zee Tamil TV': 'zeetvMMMM5',
                     '04Colors Tamil TV': self.bu + 'colors-tamil/',
                     '05Raj TV': self.bu + 'raj-tv/',
                     '06Polimer TV': self.bu + 'polimer-tv/',
                     '07Jaya TV': self.bu + 'jaya-tv/',
                     '08News & Gosips': self.bu + 'news-gossips/',
                     '09Tamil TV Programs': self.bu + 'tamil-tv-programs/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu + '?s='}
                     
    def get_menu(self):
        return (self.list,7,self.icon)

    def get_second(self,iurl):
        """
        Get the list of shows.
        :return: list
        """
        cats = {'suntv': {'01SunTV Serials': self.bu + 'sun-tv/sun-tv-serials/',
                          '02SunTV Shows': self.bu + 'sun-tv/sun-tv-shows/'},
                'vijaytv': {'01VijayTV Serials': self.bu + 'vijay-tv/vijay-tv-serials/',
                            '02VijayTV Shows': self.bu + 'vijay-tv/vijay-tv-shows/'},
                'zeetv': {'01ZeeTV Serials': self.bu + 'zee-tamil-tv/zee-tamil-tv-serials/',
                          '02ZeeTV Shows': self.bu + 'zee-tamil-tv/zee-tamil-tv-shows/'}}

        categories = []

        for title,url in sorted(cats[iurl].iteritems()):
            categories.append((title[2:],self.icon,url))   
        
        return (categories,7)
        
    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Tamil Dhool')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('main', {'id':'main'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class':'navigation'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('article')
        
        for item in items:
            try:
                title = h.unescape(item.h3.text)
            except:
                title = h.unescape(item.find('a')['title'])
            title = self.clean_title(title)
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['data-lazy-src']
            except:
                thumb = self.icon
            movies.append((title, thumb, url))
        
        if 'next' in str(Paginator):
            nextli = Paginator.find('a', {'class':re.compile('^next')})
            purl = nextli.get('href')
            currpg = Paginator.find('span').text
            lastpg = Paginator.findAll('a', {'class':'page-numbers'})[-1].text
            title = 'Next Page.. (Currently in Page %s of %s)' % (currpg,lastpg)
            movies.append((title, self.nicon, purl))
        
        return (movies,8)

    def get_videos(self,url):
        videos = []
        h = HTMLParser.HTMLParser()    
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class':'content-area'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('video')
            for link in links:
                vidurl = link.find('source')['src']
                self.resolve_media(vidurl,videos)
        except:
            pass

        try:
            links = videoclass.findAll('noscript')
            for link in links:
                vidurl = link.find('iframe')['src'].strip()
                self.resolve_media(vidurl,videos)
        except:
            pass
            
        try:
            if 'noscript' not in str(videoclass):
                links = videoclass.findAll('iframe')
                for link in links:
                    vidurl = link.get('src').strip()
                    self.resolve_media(vidurl,videos)
        except:
            pass
            
        return videos
