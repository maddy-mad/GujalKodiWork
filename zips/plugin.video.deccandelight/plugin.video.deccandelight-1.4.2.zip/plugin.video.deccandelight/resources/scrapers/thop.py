'''
thoptv deccandelight plugin
Copyright (C) 2017 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from main import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests, base64, json
import HTMLParser
import xbmc

class thop(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://watch.thoptv.com/channels/'
        self.icon = self.ipath + 'thop.png'
        self.qvalues = ['Low','Med','Default','Good','High']
        self.bvalues = ['250','400','600','800','1200']
        self.qual = self.qvalues[int(self.settings('thopqual'))]
        self.bitrate = self.bvalues[int(self.settings('thopqual'))]
        self.list = {'01Tamil TV': self.bu + 'tamil/',
                     '02Telugu TV': self.bu + 'telugu/',
                     '03Malayalam TV': self.bu + 'malayalam/',
                     '04Kannada TV': self.bu + 'kannada/',
                     '05Hindi TV': self.bu + 'hindi/',
                     '06English TV': self.bu + 'english/',
                     '08Marathi TV': self.bu + 'marathi/',
                     '10Gujarati TV': self.bu + 'gujarati/'}
            
    def get_menu(self):
        return (self.list,7,self.icon)
        
    def get_items(self,iurl):
        channels = []
        h = HTMLParser.HTMLParser()
        mlink = SoupStrainer('div', {'class':'items'})
        plink = SoupStrainer('div', {'class':'resppages'})
        nextpg = True
        while nextpg:
            nextpg = False
            html = requests.get(iurl, headers=self.hdr).text
            mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
            items = mdiv.findAll('article')
            for item in items:
                title = h.unescape(item.h3.text).encode('utf8')
                if '(' in title:
                    title = re.findall('(.+?)\s\(',title)[0]
                url = item.h3.find('a')['href']
                thumb = item.find('img')['src']
                channels.append((title, thumb, url))
            Paginator = BeautifulSoup(html, parseOnlyThese=plink)
            if 'chevron-right' in str(Paginator):
                iurl = Paginator.findAll('a')[-1].get('href')
                nextpg = True
        return (sorted(channels),9) 

    def get_video(self,url):

        html = requests.get(url, headers=self.hdr).text
        stream_url = None
        
        tlink = re.findall('<iframe.+?src=[\'"]([^\'"]+)', html)[0]
        if tlink.startswith('/'):
            tlink = 'http://thoptv.stream' + tlink
        #xbmc.log('%s is extracted.\n'%tlink,xbmc.LOGNOTICE)
        if 'Clappr.Player' in html:
            stream_url = re.findall("Clappr\.Player.+?source:\s*'([^']+)", html)[0]
        elif 'thoptv.' in tlink:          
            if 'dt.php' in tlink:
                stream_url = re.findall('source\s*src\s*=\s*"([^"]+)',html)[0]
            elif 'yp.php' in tlink:
                tlink = re.findall('<iframe.+?src=[\'"].*?(http[^\'"]+)', html)[0]
                html = requests.get(tlink, headers=self.hdr, allow_redirects=False).headers
                jd = json.loads(base64.b64decode(html['location'].split('code=')[1]))
                stream_url = jd['streamurl2'] + '|User-Agent=%s'%self.hdr['User-Agent']
            else:
                html = requests.get(tlink, headers=self.hdr).text
                if 'var stream' not in html:
                    thlink = re.findall('.+/',tlink)[0]
                    thlink += re.findall('href="([^"]+)"\s*target[^>]+>%s'%self.qual,html)[0]
                    headers = self.hdr
                    headers['Referer'] = tlink
                    r = requests.get(thlink, headers=headers)
                    thlink = r.url
                    html = r.text
                    user = re.findall('Username".+?value="([^"]+)',html)[0]
                    try:
                        passwd = re.findall('Password".+?value="([^"]+)',html)[0]
                    except:
                        passwd = ''
                    submit = re.findall('Submit".+?value="([^"]+)',html)[0].encode('utf-8')
                    values = {'Username' : user,
                              'Password' : passwd,
                              'Submit' : submit}
                    headers['Referer'] = thlink
                    html = requests.post(thlink, data=values, headers=headers).text
                    values,varname = re.findall('var\s((.+?)=[^;]+)',html)[1]
                    exec(values)
                    formula = re.findall('(%s\[[^;]+)'%varname,html)[0]
                    pars = re.findall('%s\[.+?\s([^\+;]+)'%varname,html)
                    for i in range(1,len(pars)):
                        exec(pars[i] + '=' + re.findall('%s\s*=\s*([^;]+)'%pars[i],html)[0])
                    stream_url = eval(formula)

        elif 'gohellotv.' in tlink:
            html = requests.get(tlink, headers=self.hdr).text
            stream_url = re.findall('var\sdelivery\s*=\s*"([^"]+)',html)[0]
        elif ('dacast.' in tlink) or ('streamingasaservice.' in tlink):
            surl = tlink.split('.com')[1]
            headers = self.hdr
            headers['Referer'] = 'http://iframe.dacast.com/'
            act_data = requests.get('http://json.dacast.com' + surl, headers=headers).json()
            try:
                act_url = act_data['hls']
                if 'http' not in act_url:
                    act_url = 'http:' + act_url
                act_data = requests.get('https://services.dacast.com/token/i%s?'%surl, headers=headers, verify=False).json()
                new_token = act_data['token']
                stream_url = act_url + new_token
            except:
                stream_url = act_data['rtmp']
        elif '.m3u8' in tlink:
            stream_url = tlink + '|User-Agent=%s'%self.hdr['User-Agent']
        else:
            xbmc.log('%s not resolvable.\n'%tlink,xbmc.LOGNOTICE)
                       
        return stream_url